# HabitPro PWA

Play Store’a hazır PWA paketi.

## Dosyalar
- `index.html` — Uygulama
- `manifest.json` — PWA manifest
- `sw.js` — Offline service worker
- `icon-192.png` / `icon-512.png` — İkonlar

## Nasıl yayınlanır?

### 1. Ücretsiz host et
- **Netlify:** Klasörü sürükle-bırak → netlify.com/drop
- **Vercel:** vercel.com → Import
- **GitHub Pages:** Repo’ya yükle, Pages aç

### 2. PWABuilder
1. https://www.pwabuilder.com adresine git
2. Yayınladığın URL’yi yapıştır
3. Android paketini (AAB) indir
4. Google Play Console’a yükle

### 3. Play Console
- Developer hesabı ($25 tek seferlik)
- Uygulama oluştur → AAB yükle
- Gizlilik politikası URL’si (uygulama içindeki metin yeterli başlangıç için)
- İçerik derecelendirmesi doldur
- Yayınla

## Özellikler
- Alışkanlık ekle / düzenle / sil / arşivle
- Streak, istatistik, heatmap
- Ruh hali takibi
- Premium (demo)
- Bildirimler
- Onboarding
- Dışa / içe aktarma
- Offline
- Gizlilik + Kullanım şartları
